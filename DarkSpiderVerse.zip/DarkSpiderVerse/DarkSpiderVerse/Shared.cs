﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace DarkSpiderVerse
{
    /// <summary>
    /// This class is used to share the size of the screen between classes.
    /// </summary>
    public class Shared
    {

        public static Vector2 stage;

    }
}
